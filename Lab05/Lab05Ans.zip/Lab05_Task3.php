<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 05 Task 3</title>
</head>

<body>
<?php
    $myForm = <<<EOD
	  <form method="post" action="$_SERVER[PHP_SELF]">
      <p><h2>Add a new customer</h2></p>
	  <p><label>Customer ID <input type="text" name="tfID" required="required" /></label>  </p>
      <p><label>Customer Name <input type="text" name="tfName" required="required" /></label></p>
      <p><label>Password <input type="password" name ="tfPswd" required="required"/></label></p>
      <p><label>Gender <input type="radio" name="rbGender" value="M" checked="checked" /> Male</label>
			           <input type="radio" name="rbGender" value="F" /> Female</label></p>
      <p>
        <input type="submit" value="Submit" />
        <input type="reset" value="Reset" />
      </p>
    </form>  
EOD;
    echo $myForm;
	if(isset($_POST['tfID'])) {
		$hostname = "127.0.0.1";
	    $username = "root";
	    $pwd = "";
	    $db = "lab05";
	    $conn = mysqli_connect($hostname, $username, $pwd, $db) or die(mysqli_connect_error());
		
		$sql = "SELECT * FROM customers WHERE custID='$_POST[tfID]'";
		$rs = mysqli_query($conn, $sql) or die(mysqli_error($conn));
		if(mysqli_num_rows($rs) > 0) 
			echo "<h2>Record already exist!</h2>";
		else {
			extract($_POST);
			$sql = "INSERT INTO customers (custID, custName, custPswd, custGender) VALUES ('$tfID', '$tfName', '$tfPswd', '$rbGender')";
			mysqli_query($conn, $sql) or die (mysqli_error($conn));
			if(mysqli_affected_rows($conn) > 0)
				echo "<h2>A record is added successfully</h2>";
		}
		
		mysqli_free_result($rs);
		mysqli_close($conn);
	}
?>
</body>
</html>