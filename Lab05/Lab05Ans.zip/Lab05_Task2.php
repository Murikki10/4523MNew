<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 05 Task 2</title>
</head>

<body>
<?php
	$hostname = "127.0.0.1";
	$username = "root";
	$pwd = "";
	$db = "lab05";
	$conn = mysqli_connect($hostname, $username, $pwd, $db) or die(mysqli_connect_error());
	
	$sql = "SELECT * FROM customers";
	$rs = mysqli_query($conn, $sql) or die(mysqli_error($conn));
	
	echo '<table border="1">
    	     <tr><th>Cust ID</th><th>Cust Name</th><th>Cust Password</th><th>Cust Gender</th></tr>';
	while($rc = mysqli_fetch_assoc($rs)) 
		printf('<tr><td>%s</td>
	                <td><input type="text" value="%s" /></td>
					<td><input type="text" value="%s" /></td>
		 	        <td><label><input type="radio" name="rbG%s" %s />Male</label>
				 	    <label><input type="radio" name="rbG%s" %s />Female</label></td></tr>', 
				$rc['custID'], $rc['custName'], $rc['custPswd'], 
				$rc['custID'], ($rc['custGender']=='M' ? 'checked="checked"' : ''), 
				$rc['custID'], ($rc['custGender']=='F' ? 'checked="checked"' : ''));

	echo '</table>';
	
	mysqli_free_result($rs);
	mysqli_close($conn);
?>
</body>
</html>