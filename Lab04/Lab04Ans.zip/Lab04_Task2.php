<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 4 Task 2</title>
</head>

<body>
<?php
	$myForm= <<< EOD
		<h3>Add Items Form (ABC Canteen)</h3>
		<form method="post" action="$_SERVER[PHP_SELF]">
	  		<p>Item Name <input type="text" name="iName" required="required" /></p>
			<p>Item Price (HK$) <input type="number" name="iPrice" required="required" /></p>
	  		<p>Item Type
			   <input type="radio" name="iType" value="Food" /> Food 
			   <input type="radio" name="iType" value="Drink" /> Drink 
			</p>
			<input type="submit" value="Confirm" name="submit" />
	</form>
EOD;

	echo $myForm;

	if(isset($_POST['submit'])) {
	 	extract($_POST);
		$typeNotSelected = !isset($iType);
		if($typeNotSelected) 
			echo "<br />ERROR: Must select an item type";

		$priceTooHigh = $iPrice > 100;
		if($priceTooHigh)
			echo "<br />ERROR: Item price HK\$$iPrice is too high";

		if(!($typeNotSelected or $priceTooHigh))
			printf("<br />Item %s (HK$%d) will be added to system",
		            $iName, $iPrice);
	} 
?>
</body>
</html>