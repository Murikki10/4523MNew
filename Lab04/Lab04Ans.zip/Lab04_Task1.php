<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 4 Task 1</title>
</head>

<body>
<?php
	$myForm= <<< EOD
		<h3>Movie Club</h3>
		<form method="post" action="$_SERVER[PHP_SELF]">
	  		<p>Use <input type="number" name="points" min="500" required="required" />
	           reward points (minimum is 500) 
			</p>
	  		<p>To redeem tickets of the following movies: <br />
			   <input type="checkbox" name="movie[]" value="Titanic" /> Titanic <br />
			   <input type="checkbox" name="movie[]" value="Star Wars" /> Star Wars <br />
			</p>
			<input type="submit" value="Redeem Now" name="submit"/>
	</form>
EOD;

	if(isset($_POST['submit'])) {
	 	extract($_POST);
	 	$numMovies = (isset($movie)) ? count($movie) : 0;
	 	if($numMovies == 0 )
	 		echo "ERROR: You must select at least 1 movie";
	 	else if ($points < 1000 and $numMovies > 1) 
	 		echo "ERROR: $points points can redeem a ticket of ONE movie only";
	 	else
	 		printf("You have redeem %d ticket(s) for: %s", 
	 	           $numMovies, implode(" and ", $movie));
	 } else 
		echo $myForm;
?>
</body>
</html>