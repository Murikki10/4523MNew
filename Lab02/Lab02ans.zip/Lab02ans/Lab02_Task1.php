<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 02 Task 1</title>
</head>

<body>
<?php
	for($i=1; $i<=10; $i++)
		printf("%1\$d * %1\$d is %2\$d <br />", $i, $i*$i);
?>
</body>
</html>