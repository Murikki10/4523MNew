<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 02 Task 3</title>
</head>

<body>
<?php
	$fib = array(1, 1);
	for($i=2; $i<20; $i++) 
		$fib[] = $fib[$i-1] + $fib[$i-2];

	echo '<table border="1" width="50%">';
	foreach($fib as $i=>$v)
		printf("<tr><td>%d</td><td>%d</td></tr>", $i+1, $v);
	echo "</table>";
?>
</body>
</html>