<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 02  Task 2</title>
</head>

<body>
<?php
	$mathMark = array(70, 40, 60, 50, 20, 30, 10, 100, 80, 90);
	
	$index = 0;
	do {
		echo $mathMark[$index++] . "     ";
	} while($index < count($mathMark));
	
	$max = $mathMark[0];
	$index = 1;
	while($index < count($mathMark)) {
		if($mathMark[$index] > $max)
			$max = $mathMark[$index];
		$index++;
	}
	echo "<br />The maximum mark is $max";
	
	$min = $mathMark[0];
	for($i=1; $i<count($mathMark); $i++)
		if($mathMark[$i] < $min)
			$min = $mathMark[$i];
	echo "<br />The minimum mark is $min";	
?>
</body>
</html>