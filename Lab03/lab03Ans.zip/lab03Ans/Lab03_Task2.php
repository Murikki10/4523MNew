<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab03 Task 2</title>
<?php
	function calTwoNumbers($n1, $n2) {
		return ($n1 + $n2);
	}
?>
</head>

<body>
<?php
	echo "<h2>Calculate Two Numbers Function</h2>";
	printf("The total of two numbers %d and %d is %d", 
	        $_POST['tfNum1'], $_POST['tfNum2'],calTwoNumbers($_POST['tfNum1'], $_POST['tfNum1']));
?>
</body>
</html>