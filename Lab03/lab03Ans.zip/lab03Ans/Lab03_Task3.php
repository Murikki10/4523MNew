<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 01 Task 3</title>
</head>

<body>
<?php
  extract($_POST);
  $age = date('Y') - $tfBYear;     

  if ($age >= 18)
	  echo "<h3>Welcome! $tfFName $tfLName</h3>
		     	<h3>You are now $age years old, so you can fill this form.</h3>";
	else
	  echo "<h3>Sorry: Your age is: $age.</h3>
			    <h3>You should be over 18 to fill this form</h3>";
?>
</body>
</html>