<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab03 Task 1</title>
</head>

<body>
<?php
	printf("%s graduate in %d is %s an alumni with comment: %s", 
	        $_GET['tfName'], $_GET['tfGYear'], ($_GET['rbAlumni'] == "No") ? "not ": "" , $_GET['taComment']);
?>
</body>
</html>