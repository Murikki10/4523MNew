<html>
    <head></head>
        <title>Lab 01 - Task 2</title>
    </head>
    <body>
        <?php
        $name = "wong chun wing";
        $age = 20;
        $weight = 70.5;

        echo "Name: " . $name . "</br>";
        echo "Age: " . $age . " years old</br>";
        echo "Weight: " . $weight . " Kg</br>";

        ?>
    </body>
</html>