<html>
    <head>
        <title>Lab 01 - Task 1</title>
    </head>
    <body>
        <?php
            echo "wong chun wing</br>";  
            echo "20 years old</br>";
            echo "70Kg</br>";
        ?>
    </body>
</html>