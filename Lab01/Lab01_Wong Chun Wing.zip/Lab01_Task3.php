<html>
    <head>
        <title>Lab 01 - Task 3</title>
    </head>
    <body>
        <?php
        $y = 6;
        $x = 20;

        echo $x . " + " . $y . " = " . ($x + $y) . "</br>";
        echo $x . " - " . $y . " = " . ($x - $y) . "</br>";
        echo $x . " * " . $y . " = " . ($x * $y) . "</br>";
        echo $x . " / " . $y . " = " . ($x / $y) . "</br>";
        echo $x . " % " . $y . " = " . ($x % $y) . "</br>";

        ?>
    </body>
</html>