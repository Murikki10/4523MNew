<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 01 Task 3</title>
</head>

<body>
<?php
	$x = 20;
	$y = 6;
	 
	printf("%1\$d + %2\$d = %3\$d <br /> 
	        %1\$d - %2\$d = %4\$d <br />
			%1\$d * %2\$d = %5\$d <br / > 
			%1\$d / %2\$d = %6\$.11f <br /> 
			%1\$d %% %2\$d = %7\$d <br /> ", 
			$x, $y, $x+$y, $x-$y, $x*$y, $x/$y, $x%$y);
?>
</body>
</html>