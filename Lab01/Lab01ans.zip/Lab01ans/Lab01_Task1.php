<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 01 Task 1</title>
</head>

<body>
<?php
	echo "Name: Chan Tai Man, John <br />";
	print ('Age: 18 <br />');
	printf("Weight: %d kg", 50);
?>
</body>
</html>