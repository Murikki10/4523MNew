<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Lab 01 Task 2</title>
</head>

<body>
<?php
	$name = "Chan Tai Man, John";
	$age = 18;
	$weight = 50.0;
	
	echo "Name: $name <br />";
	print ("Age: $age <br />");
	printf("Weight: %d kg", $weight);
?>
</body>
</html>